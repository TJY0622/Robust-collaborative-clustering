clc
clear
n1=600;
n2=300;
n3=0;
n=50;
X=[n1+n*rand(1,4),n3+n*rand(1,4);
    n2+n*rand(1,4),n3+n*rand(1,4);
    n3+n*rand(1,4),n1+n*rand(1,4);
    n3+n*rand(1,4),n2+n*rand(1,4);
    n2+n*rand(1,8);
    n1+n*rand(1,8);]';
Xv=X./255;
DDv = pdist2(Xv,Xv,'squaredeuclidean');
figure('Name','X')
hold on
axis([0 9 0 7]); 
for i=1:8
    for j=1:6
        scatter(i,j,X(8-i+1,6-j+1),'b','filled','s');
    end
end
box on
hold off
[WT,VV] = NNDSVD(X',3,0);
[ST,HT] = NNDSVD(VV,2,0);
HT=HT';
lambdav=-4;
alphav=2;
beta=-4;
Pv=2;
[W,S,H]=RLOMTFAG(X',WT,ST,HT,DDv,10^lambdav,10^alphav,10^beta,100,10^-10,Pv,'squaredeuclidean');

figure('Name','W')
hold on
axis([0.5 3.5 0 7]); 
if max(max(W))>1000
    kkkkk=0.5;
elseif max(max(W))>100
    kkkkk=5;
elseif max(max(W))>10
    kkkkk=50;
elseif max(max(W))>1
    kkkkk=500;
else
    kkkkk=1000;
end
for i=1:6
    for j=1:3
        scatter(j,i,kkkkk*W(i,j),'b','filled','s');
    end
end
box on
hold off

figure('Name','S')
hold on
axis([0.5 2.5 0.5 3.5]); 
if max(max(S))>1000
    kkkkkp=0.1;
elseif max(max(S))>100
    kkkkkp=1;
elseif max(max(S))>10
    kkkkkp=10;
elseif max(max(S))>1
    kkkkkp=100;
else
    kkkkkp=1000;
end
if min(min(S))<-1000
    kkkkkn=0.1;
elseif min(min(S))<-100
    kkkkkn=1;
elseif min(min(S))<-10
    kkkkkn=10;
elseif min(min(S))<-1
    kkkkkn=100;
else
    kkkkkn=1000;
end
for i=1:3
    for j=1:2
        if S(i,j)>=0
            scatter(j,i,kkkkkp*S(i,j),'b','filled','s');
        else
            scatter(j,i,-kkkkkn*S(i,j),'r','filled','s');
        end
    end
end
box on
hold off


figure('Name','H')
hold on
axis([0 9 0.5 2.5]); 
if max(max(H))>1000
    kkkkk=0.5;
elseif max(max(H))>100
    kkkkk=5;
elseif max(max(H))>10
    kkkkk=50;
elseif max(max(H))>1
    kkkkk=500;
else
    kkkkk=1000;
end
for i=1:8
    for j=1:2
        scatter(i,j,kkkkk*H(i,j),'b','filled','s');
    end
end
box on
hold off