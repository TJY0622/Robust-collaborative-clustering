clc
clear
n=20;
n_abnormal=5;
k=1/4;
wucha=0.25;
x=linspace(1,10,n);
x=x+wucha*rand(1,n);
y=k*x+wucha*randn(1,n);
x_abnormal=0+10*rand(1,n_abnormal)+wucha*rand(1,n_abnormal);
error=-20;
y_abnormal=k*x_abnormal+wucha*randn(1,n_abnormal)+error;
X=[x,x_abnormal];
Y=[y,y_abnormal];
XX=[X;Y];
[r,c]=size(XX);
T=20;
K_MEHX=zeros(T,1);
P=7;
Xv=X./255;
DDv = pdist2(Xv',Xv','squaredeuclidean');
distance='squaredeuclidean';
for i=1:T
UTv=rand(r,2);
STv=rand(2,1);
Vv=rand(c,1);
limiter=500;
epsilon=10^-10;

lambdav=-8;alphav=-2;beta=-6;Pv=6;
[Wv,Sv,Hv,Gv]=RLOMTFAG(XX,UTv,STv,Vv,DDv,10^lambdav,10^alphav,10^beta,limiter,10^-10,Pv,distance);
WMEHx=Wv*Sv;
K_MEHX(i)=WMEHx(2)/WMEHx(1);  

end
xplot=0:0.5:12;
hold on
grid on
box on
h1=scatter(x,y,100,'ko');
h2=scatter(x_abnormal,y_abnormal,100,'bo');
h=plot(xplot,mean(K_MEHX)*xplot,'--r','LineWidth',2);
legend([h1,h2,h],{'real data','noise data','curve fitting by RLOMFAG'},'FontSize',12)
hold off
