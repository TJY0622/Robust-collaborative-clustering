function [U,S,V,Gv,obj,Result]=RLOMTFAG(X,U0,S0,V0,DDv,lambdav,alphav,beta,limiter,epsilon,kv,distance,Tlabel)
if nargin < 13
    Tlabel = [];
    time=0;
else
    time=1;
end
[~,numv]=size(X);
[Gv,gamma,~]=update_AG_mean(DDv,kv);
Dv = diag(sum(Gv));
GGv=sparse(numv,numv);
Gv=sparse(Gv);
Dv=sparse(Dv);
if time==1
    L=Dv-Gv;        
end
obj=[];
Result=[];


for iter=1:limiter
    Y=X-U0*S0*V0';
    Ev=sqrt(sum(Y.^2,1));
    W=max(2*Ev,epsilon);
    W=diag(1./W);
    W=sparse(W);
    if time==1
    g=beta*norm(Gv+DDv./(2*gamma),'fro')^2;
    HH=diag(sum(V0,1));
    HH=sparse(HH);
    SVt=S0*V0';
    XtU=X'*U0;
    r=size(U0,2);
    Gamma=SVt*W*XtU-SVt*W*SVt'-lambdav*(S0*HH*S0'-SVt*XtU);
    part1=sum(Ev)+alphav*trace(V0'*L*V0);%sum(Ev) trace(Y*W*Y')
    part2=0;
    US=U0*S0;
    for i=1:numv
       part2=part2+trace(X(:,i)*sum(V0(i,:))*X(:,i)'); 
    end
    part2=part2+trace(US*HH*US')-2*trace(X*V0*US');
    part2=part2*lambdav;
    obj= [obj;part1+part2+g+trace(Gamma*(U0'*U0-eye(r)))];
    clear US part1 part2 g r Gamma
    Accuracy=0;MIhat=0;
    for k=1:10
        [a,b] = evalResults(V0',Tlabel);
        Accuracy=Accuracy+a;
        MIhat=MIhat+b;
    end
    Result=[Result;Accuracy/10,MIhat/10];
    end
    
    V1=updateV_RLOMTFAG(X,U0,S0,V0,W,lambdav,alphav,Gv,Dv,epsilon);
    if norm(V1-V0,'fro')^2<10^-5
        V0=V1;
        break
    else
        V0=V1;
    end
    S0=updateS_RLOMTFAG(X,U0,V0,W,lambdav);
    U0=updateU_RLOMTFAG(X,U0,V0,S0,W,lambdav);
   

    if norm(GGv-Gv,'fro')^2>10^-3
    GGv=Gv;
    VV=V0./max(max(V0));
    if strcmp(distance,'squaredeuclidean')
%         distV =  pdist2(VV,VV,'squaredeuclidean');
        distV =L2_distance_1(VV',VV');
    elseif strcmp(distance,'cosine')
        distV = pdist2(VV,VV,'cosine');
    end
    clear VV
    Gv = zeros(numv);
    for i=1:numv
        idxa0 = 1:numv;
        dfi = distV(i,idxa0);
        dxi = DDv(i,idxa0);
        ad = -(dxi+beta*dfi)/(2*gamma);
        Gv(i,idxa0) = EProjSimplex_new(ad);
    end
    Gv = (Gv+Gv')/2;
    Dv = diag(sum(Gv));
    Gv=sparse(Gv);
    Dv=sparse(Dv);
    end

end
U=U0;
V=V0;
S=S0;
end