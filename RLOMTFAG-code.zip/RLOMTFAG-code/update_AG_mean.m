function [G,gamma,eta]=update_AG_mean(D,k)
d=sort(D,2);
dtk=mean(d(:,k+2));
gamma=(k*dtk-mean(sum(d(:,2:k+1),2)))/2;
eta=dtk/(2*gamma);
G=max(eta-D./(2*gamma),0);
end