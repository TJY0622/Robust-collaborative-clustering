clc
clear

name={'ORL_32x32','Yale_32x32','COIL100',...
    'UMIST','JAFFE','BBCSport',...
    'UCI_Digits','Reuters-21578'};
parameter=[-10,-4,-4,9,46;
    -5,3,-6,9,23;
    -6,4,-7,14,160;
    -9,-3,-2,7,27;
    -10,-4,-4,8,18;
    -4,-2,-5,4,5;
    -7,-2,-3,10,12;
    -3,1,5,9,12;];
for iii= [4,5]
Selection=name{iii};
load(strcat(Selection,'.mat'));
X=fea;
Min=min(min(fea));
if Min<0
   fea=fea-Min;
end
total=unique(gnd);
exclude=[];
ceshi=setdiff(total,exclude);
%%
nr=length(ceshi);
rr=[];
Tlabel=[];
for i=1:nr
    lr=find(gnd==ceshi(i));
    if size(lr,1)>size(lr,2)
        rr=[rr;lr];
    else
        rr=[rr;lr'];
    end
    Tlabel=[Tlabel;i*ones(length(lr),1)];
end
X=X(:,rr);
rX=sum(X,2);
X(rX==0,:)=[];
[m,n]=size(X);
if strcmp(Selection,'ORL_32x32') || strcmp(Selection,'Yale_32x32')||strcmp(Selection,'COIL100')||strcmp(Selection,'UMIST')||strcmp(Selection,'JAFFE')
Xv=X./255;
distance='squaredeuclidean';
DDv = pdist2(Xv',Xv',distance);
else
Xv=X./max(max(X));
distance='cosine';
DDv = pdist2(Xv',Xv','cosine'); 
end
limiter=100;
epsilon=10^-10;
T=10;
ME=zeros(T,2);
TimeME=zeros(T,1);
for t=1:T
    [UTv,VV] = NNDSVD(X,parameter(iii,5),0);
    [STv,Vv] = NNDSVD(VV,nr,0);
    Vv=Vv';
    tic
    [Wv,Sv,Hv]=RLOMTFAG(X,UTv,STv,Vv,DDv,10^parameter(iii,1),10^parameter(iii,2),10^parameter(iii,3),limiter,epsilon,parameter(iii,4),distance);
    timeME=toc;
    TimeME(t)=timeME;
    [AccuracyMEv,MIhatMEv] = evalResults(Hv',Tlabel);
    ME(t,:)=[AccuracyMEv,MIhatMEv];
    
end

result1=[mean(ME,1);std(ME,0,1)];
mean(TimeME)
end