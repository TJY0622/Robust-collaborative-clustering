clc
clear
newdata = 1;
datatype = 1; % 1: two-moon data, 2: three-ring data,

if newdata == 1
    clearvars -except datatype;
    if datatype == 1
        num0 = 100; X = twomoon_gen(num0); c = 2; y = [ones(num0,1);2*ones(num0,1)];
    elseif datatype == 2
        num0 = 500; [X, y] = three_ring_gen(num0,0.05); c = 3;
    end
end


X1=X(y==1,:);
X2=X(y==2,:);
if datatype==2
X3=X(y==3,:);
end
X=X';
Xv=X./255;
DDv = pdist2(Xv',Xv','squaredeuclidean');
[nn,mm]=size(X);
r=c;
k=5;

Size=75;

hold on
axis square
box on
p1=scatter(X1(:,1),X1(:,2),Size,'ro');
p2=scatter(X2(:,1),X2(:,2),Size,'bo');
h=legend([p1,p2],'data point 1','data point 2');
if datatype==2
p3=scatter(X3(:,1),X3(:,2),Size,'go');
h=legend([p1,p2,p3],'data point 1','data point 2','data point 3');
end
hold off


options = [];
options.WeightMode = 'Binary';  
options.k=k;
G = constructW(X',options);

cv=c*c;
Vv=rand(mm,r);
UTv=rand(nn,cv);
STv=rand(cv,r);
limiter=0;
lambdav=-8;
alphav=-2;
beta=-6;
Pv=k+5;
[Wv,Sv,Hv,Gv]=RLOMTFAG(X,UTv,STv,Vv,DDv,10^lambdav,10^alphav,10^beta,limiter,10^-10,Pv);
% length(find(Gv>0))


S2=Gv;
name='Eq. (2)';
KK=Pv;

% S2=full(G);
% name='k-NN';
% KK=k;


ll=36;
ll2=144;
[ns2,ms2]=find(S2>0);
hold on
axis square
box on
for i=1:length(ns2)
    f21=[X(2,ns2(i)),X(2,ms2(i))];
    f22=[X(1,ns2(i)),X(1,ms2(i))];
    h1=plot(f22,f21,'-k','LineWidth',1);
end
p1=scatter(X1(:,1),X1(:,2),Size,'ro');
p2=scatter(X2(:,1),X2(:,2),Size,'bo');
h=legend([p1,p2,h1],'data point 1','data point 2',strcat(name,'with k=',num2str(KK)));
if datatype==2
p3=scatter(X3(:,1),X3(:,2),Size,'go');
h=legend([p1,p2,p3,h1],'data point 1','data point 2','data point 3',strcat(name,'with k=',num2str(KK)));
end
set(h,'FontSize',11,'FontWeight','normal')
hold off