function [Ss]=updateS_RLOMTFAG(X,U,V,Yv,lambdav)
D=lambdav*diag(sum(V,1));
Ss=U'*(X*(lambdav*eye(size(X,2))+Yv)*V)/(V'*Yv*V+D);
end